package control;

import org.json.JSONObject;

public interface json {
    public JSONObject json(String file);
}
