package entity;

public class RamenInfo {
    public int ramen = 0;
    public String[] ramenOrder = {null, null, null, null, null};
}
